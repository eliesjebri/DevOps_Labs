#! /bin/sh

echo 0 : $0
if [ -n "$1"  ] ; then echo 1  : $1  ; fi
if [ -n "$2"  ] ; then echo 2  : $2  ; fi
if [ -n "$3"  ] ; then echo 3  : $3  ; fi
if [ -n "$4"  ] ; then echo 4  : $4  ; fi
if [ -n "$5"  ] ; then echo 5  : $5  ; fi
if [ -n "$6"  ] ; then echo 6  : $6  ; fi
if [ -n "$7"  ] ; then echo 7  : $7  ; fi
if [ -n "$8"  ] ; then echo 8  : $8  ; fi
if [ -n "$9"  ] ; then echo 9  : $9  ; fi
if [ -n "${10}" ] ; then echo 10 : ${10} ; fi
