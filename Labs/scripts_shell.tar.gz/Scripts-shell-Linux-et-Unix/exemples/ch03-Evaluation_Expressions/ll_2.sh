#! /bin/sh
ls -l "$*"
