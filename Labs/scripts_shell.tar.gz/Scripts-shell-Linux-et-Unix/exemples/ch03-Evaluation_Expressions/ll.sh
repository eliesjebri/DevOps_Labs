#! /bin/sh
ls -l "$@"
