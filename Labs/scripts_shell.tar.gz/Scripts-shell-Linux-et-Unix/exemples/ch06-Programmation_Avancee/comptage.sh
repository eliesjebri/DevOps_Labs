#! /bin/sh

for i in $(seq 1 4) ; do
	echo $i
	sleep 10
done
