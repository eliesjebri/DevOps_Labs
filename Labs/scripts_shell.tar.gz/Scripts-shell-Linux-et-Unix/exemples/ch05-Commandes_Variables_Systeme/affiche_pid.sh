#! /bin/sh
echo "PID du shell : $$"
